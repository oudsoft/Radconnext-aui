$.widget( "custom.iconitem", {
  options: {
    elementType: 'icon',
    left: 0,
    top: 0,
    width: '30',
    height: 'auto',
    imgUrl: '',
    border: '1px solid yellow',
    cursor: 'pointer',
  },
  _setOption: function( key, value ) {
    this.options[key] = value;
    this._super( key, value );
  },
  _setOptions: function( options ) {
    this._super( options );
    let $this = this;
    this.render($this);
  },
  _create: function() {
    let $this = this;
    this.render($this);
  },
  render: function(me) {
    this.element.empty();
    let icoDiv = $('<div></div>');
		$(icoDiv).css({'float': 'left'});

		let hsIcon = new Image();
    hsIcon.src = this.options.imgUrl;
    $(hsIcon).css({"width": this.options.width, "height": this.options.height, "border": this.options.border, "cursor": this.options.cursor});
    $(hsIcon).on("click", function(e){
      me.options.onClick(e);
		});
    $(icoDiv).append($(hsIcon));

    this.element.append($(icoDiv));
  }
});

$.widget( "custom.imageitem", {
  options: {
    elementType: 'image',
    left: 0,
    top: 0,
    width: '100',
    height: 'auto',
    imgUrl: '',
    border: '1px solid red',
    cursor: 'pointer'
  },
  _setOption: function( key, value ) {
    this.options[key] = value;
    this._super( key, value );
  },
  _getOption: function( key ) {
    return this.options[key];
  },
  _setOptions: function( options ) {
    this._super( options );
    let $this = this;
    this.render($this);
  },
  _getOptions: function(){
    return this.options;
  },
  _create: function() {
    let $this = this;
    this.render($this);
  },
  option: function( key ){
    return this._getOption(key);
  },
  render: function(me) {
    let $this = this;
    this.element.empty();
    let imgDiv = $('<div></div>');
		$(imgDiv).css({'float': 'left'});

		let hsImage = new Image();
    hsImage.src = this.options.imgUrl;
    $(hsImage).css({"width": this.options.width, "height": this.options.height, "border": this.options.border, "cursor": this.options.cursor});
    $(hsImage).on("click", function(e){
			window.open($this.options.imgUrl, '_blank');
		});
    $(imgDiv).append($(hsImage));

    let removeLink = $('<span>x</span>');
		$(removeLink).addClass('remove');
		$(removeLink).on("click", function(e){
			//$(imgDiv).remove();
      me.options.onRemoveClick(e, imgDiv);
		});
		$(imgDiv).append($(removeLink));

    this.element.append($(imgDiv));
  }
});

let imagehistory;

$.widget( "custom.imagehistory", {
  options: {
    elementType: 'history',
    left: 0,
    top: 0,
    width: '200',
    height: 'auto',
    border: '2px solid green',
  },
  _setOption: function( key, value ) {
    this.options[key] = value;
    this._super( key, value );
  },
  _setOptions: function( options ) {
    this._super( options );
    let $this = this;
    this.render($this);
  },
  _create: function() {
    imagehistory = this;
    let $this = this;
    this.render($this);
  },
  cachedScript: function( url, options ) {
    options = $.extend( options || {}, {
      dataType: "script",
      cache: true,
      url: url
    });
    return $.ajax( options );
  },
  render: function(me) {
    this.element.empty();
    this.element.data({images: []})
    let iconCmdDiv = $('<div id="IconCmdDiv" style="width: 100%"></div>');
    let imageListDiv = $('<div id="ImageListDiv" style="width: 100%"></div>');
    this.element.append($(iconCmdDiv));
    this.element.append($(imageListDiv));
    let uploadIconProp = {imgUrl: '/images/attach-icon.png',
    onClick: function(e){me.uploadClick(e, imageListDiv)}}
    let uploadIconCmd = $( "<div></div>" ).appendTo($(iconCmdDiv)).iconitem( uploadIconProp );
    let scannerIconProp = {imgUrl: '/images/scanner-icon.png',
    onClick: function(e){me.scannerClick(e, imageListDiv)}}
    let scannerIconCmd = $( "<div></div>" ).appendTo($(iconCmdDiv)).iconitem( scannerIconProp );
  },
  uploadClick: function(e, imageListBox){
    let $this = this;
    let simpleUploadPluginUrl = "../../lib/simpleUpload.min.js";
		this.cachedScript( simpleUploadPluginUrl ).done(function( script, textStatus ) {
      $this.doOpenSelectFile(imageListBox);
		});
  },
  doOpenSelectFile: function (imageListBox){
    let $this = this;
    let fileBrowser = $('<input type="file"/>');
    $(fileBrowser).attr("name", 'patienthistory');
    $(fileBrowser).attr("multiple", true);
    $(fileBrowser).css('display', 'none');
    $(fileBrowser).on('change', function(e) {
      const defSize = 10000000;
      var fileSize = e.currentTarget.files[0].size;
      var fileType = e.currentTarget.files[0].type;
      if (fileSize <= defSize) {
        $this.doUploadImage(fileBrowser, imageListBox);
      } else {
        $(imageListBox).append('<div>' + 'File not excess ' + defSize + ' Byte.' + '</div>');
      }
    });
    $(fileBrowser).appendTo($(imageListBox));
    $(fileBrowser).click();
  },
  doUploadImage: function(fileBrowser, imageListBox) {
    let $this = this;
    var uploadUrl = $this.options.attachFileUploadApiUrl;
    $(fileBrowser).simpleUpload(uploadUrl, {
      success: function(data){
        $(fileBrowser).remove();
        setTimeout(() => {
          $this.doAppendNewImageData(data);
          let uploadImageProp = {
            imgUrl: data.link,
            onRemoveClick: function(e, imgDiv){$this.doRemoveImage(e, data.link, imgDiv)}
          };
          $( "<div></div>" ).appendTo($(imageListBox)).imageitem( uploadImageProp );
        }, 400);
      },
    });

  },
  doAppendNewImageData: function(data){
    let $this = this;
    let oldData = $this.element.data();
    if (oldData) {
      if (oldData.images.length) {
        oldData.images.push({link: data.link});
      } else {
        oldData.images = [];
        oldData.images.push({link: data.link});
      }
    } else {
      oldData.images = [];
      oldData.images.push({link: data.link});
    }
    $this.element.data(oldData);
    console.log($this.element.data());
  },
  doRemoveImage: function(e, imgLink, imageDiv){
    let $this = this;
    let data = this.element.data();
    let newData = data.images.filter((item) => {
      return (item.link !== imgLink)
    })
    this.element.data({images: newData});
    console.log($this.element.data());
    $(imageDiv).remove();
  },
  scannerClick: function(e, imageListBox){
    let $this = this;
    let scannerPluginUrl = "../../lib/scanner.js";
    this.cachedScript( scannerPluginUrl ).done(function( script, textStatus ) {
      scanner.scan($this.displayImagesOnPage, {
				"use_asprise_dialog": false,
        "output_settings": [{"type": "return-base64", "format": "jpg" }]
      });
    });
  },
  displayImagesOnPage: function(successful, mesg, response) {
    let $this = imagehistory;
    //console.log('response==> ', response);
    if(!successful) { // On error
      console.error('Failed: ' + mesg);
      return;
    }

    if(successful && mesg != null && mesg.toLowerCase().indexOf('user cancel') >= 0) { // User cancelled.
      console.info('User cancelled');
      return;
    }

    let scannedImages = scanner.getScannedImages(response, true, false); // returns an array of ScannedImage
    let imageData = scannedImages[scannedImages.length - 1].src;
    let params = {image: imageData};
    let uploadImageUrl = "/api/scannerupload";
    //let uploadImageUrl = $this.options.scanUploadApiUrl;
    $.post(uploadImageUrl, params, function(data){
      console.log(data.link);
      setTimeout(()=>{
        $this.doAppendNewImageData(data);
        let uploadImageProp = {
          imgUrl: data.link,
          onRemoveClick: function(e, imgDiv){$this.doRemoveImage(e, data.link, imgDiv)}
        };
        $( "<div></div>" ).appendTo($("#ImageListDiv")).imageitem( uploadImageProp );
      }, 400);
    });
  },
  images: function(){
    let allData = this.element.data();
    return allData.images;
  }

});
